"""diaryproject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from textwrap import indent
from django.contrib import admin
from django.urls import path
from diaryapp import views
urlpatterns = [
    # path('udp/',views.udp),
    path('admin/', admin.site.urls),
    path('login/', views.login),
    path('customerregister/', views.cregister),
    path('distributorregister/', views.distributorreg),
    path('index/', views.index),
    path('', views.index),
    path('dreg/', views.distributorreg),
    path('darea/', views.distributionarea),
    path('addsub/', views.addsubplan),
    path('adminaddcategory/', views.adminaddcategory),
    path('adminaddproducts/', views.adminaddproduct),
    path('payment/',views.paymentform),
    path('usersendcomplaint/',views.sendcomplaint),
    path('adminviewdistributer/',views.adminviewdistributer),
    path('adminviewpendingdistributer/',views.adminviewpendingdistributer),
    path('deletedistributer/',views.deletedistributer),
    path('adminviewuser/',views.adminviewuser),
    path('adminviewcategory/',views.adminviewcategory),
    path('adminviewproducts/',views.adminviewproducts),
    path('adminviewdistributionarea/',views.adminviewdistributionarea),
    path('adminviewcomplaints/',views.adminviewcomplaints),
    path('adminsendreply/',views.adminsendreply),
    path('adminhome/',views.adminhome),
    path('userhome/',views.userhome),
    path('distributorhome/',views.distributorhome),
    path('distributorviewcustomer/',views.distributorviewcustomer),
    path('distributorviewarea/',views.distributorviewarea),
    path('distributorviewproducts/',views.distributorviewproducts),
    path('distributorviewcategory/',views.distributorviewcategory),
    # path('distributorviewsubpaln/',views.distributorviewsubpaln),

    path('customerviewproducts/',views.customerviewproducts),
    path('customerviewcategory/',views.customerviewcategory),
    path('userviewreply/',views.userviewreply),
    path('approvedistributer/',views.approvedistributer),
    path('rejectdistributer/',views.rejectdistributer),
    path('pay/',views.subpayment),
    path('pay2/',views.productpayment),
    path('delet/',views.delet),
    path('admviewplan/',views.admviewplan),
    # path('pay3/',views.payment3),
    # path('pay4/',views.payment4),
    # path('pay5/',views.payment5),
    path('userviewsub/',views.viewsub),
    # path('useraddcomplaint/',views.viewsub),
    path('distviewsub/',views.distviewsub),
    path('makepayaction/',views.makepayaction),
    path('req/',views.req),
    path('Adsubscribedusers/',views.adminviewsubuser),
    path('orderproduct/',views.orderproduct),
    path('productpayment/',views.productpayment),
    path('delcat/',views.admdeletecategory),
    path('updatecate/',views.updatecategories),
    path('upcategory/',views.updatecategory),
    path('uproducts/',views.updateproducts),
    path('admdeluproducts/',views.admindeleteproducts),
    path('updateproduct/',views.updatepro),
    path('userviewmyorder/',views.uservieworder),
    path('userviewsubplan/',views.viewusersubplan),
    path('productpay/',views.productpay),
    path('distviewsubcustomers/',views.distviewsubcustomers),
    path('Distupdatecategory/',views.Distupdatecategory),
    path('Distdeletecategory/',views.Distdeletecategory),
    path('adminvieworders/',views.adminvieworders),
    path('dist_updateproduct/',views.dist_updateproduct),
    path('dist_view_complaints/',views.dist_view_complaints),
    path('unsubscrbe/',views.unsubscrbe),


    

   
    
    

]
